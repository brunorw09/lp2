﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        public const double Pi = 3.14;
        double raio, altura, volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("Raio Inválido!");
                txtRaio.Focus();
            }
            else if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura Inválida!");
                txtAltura.Focus();
            }
            else
            {
                volume = Pi * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void lblVolume_Click(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Digite somente números para o valor da Altura!");
            }
            else if (altura <= 0)
            {
                MessageBox.Show("O valor da Altura deve ser maior que Zero!");
            }
        }

        private void txtVolume_Validated(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text = "";
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out raio))
            {
                MessageBox.Show("Digite somente números para o valor de Raio!");
            }
            else if (raio <= 0)
            {
                MessageBox.Show("O valor de Raio deve ser maior que Zero!");
            }
        }
    }
}
