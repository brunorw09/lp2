using System.Windows.Forms;

namespace Pimc
{


    public partial class Form1 : Form
    {

        double peso, altura;
        public Form1()
        {

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mskAltura.Clear();
            mskPeso.Clear();
            txtimc.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo?",
               "Sa�da", MessageBoxButtons.YesNo,
               MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double imc;
            altura = Math.Pow(altura, 2);
            txtimc.Text = (peso / altura).ToString("N2");
            Double.TryParse(txtimc.Text, out imc);
            imc = Math.Round(imc, 1);
            if (imc < 18.5)
            {
                MessageBox.Show("Magreza" +
                    " Obesidade grau 0");
            }
            else if (imc < 24.9)
            {
                MessageBox.Show("Normal" +
                    " Obesidade grau 0");
            }
            else if (imc < 29.9)
            {
                MessageBox.Show("Sobrepeso" +
                    " Obesidade grau |");
            }
            else if (imc < 39.9)
            {
                MessageBox.Show("Obesidade" +
                    " Obesidade grau ||");
            }
            else
                MessageBox.Show("Obesidade grave" +
                    " Obesidade grau |||");
        }

        private void mskPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskPeso.Text, out peso) || peso <= 0)
            {
                errorProvider1.SetError(mskPeso, "Peso inv�lido");
                mskPeso.Focus();
            }
            else
            {
                errorProvider1.SetError(mskPeso, "");
            }
        }

        private void mskAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskAltura.Text, out altura) || altura <= 0)
            {
                errorProvider2.SetError(mskAltura, "Altura inv�lida");
                mskAltura.Focus();
            }
            else
            {
                errorProvider2.SetError(mskAltura, "");
            }
        }

        private void txtimc_TextChanged(object sender, EventArgs e)
        {

        }

        private void mskAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
