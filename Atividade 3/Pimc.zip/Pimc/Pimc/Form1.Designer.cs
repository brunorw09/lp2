﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            mskPeso = new MaskedTextBox();
            mskAltura = new MaskedTextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtimc = new TextBox();
            button1 = new Button();
            btnLimpar = new Button();
            button3 = new Button();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            SuspendLayout();
            // 
            // mskPeso
            // 
            mskPeso.Location = new Point(226, 50);
            mskPeso.Name = "mskPeso";
            mskPeso.Size = new Size(308, 23);
            mskPeso.TabIndex = 0;
            mskPeso.MaskInputRejected += maskedTextBox1_MaskInputRejected;
            mskPeso.Validated += mskPeso_Validated;
            // 
            // mskAltura
            // 
            mskAltura.Location = new Point(226, 100);
            mskAltura.Name = "mskAltura";
            mskAltura.Size = new Size(308, 23);
            mskAltura.TabIndex = 1;
            mskAltura.MaskInputRejected += mskAltura_MaskInputRejected;
            mskAltura.Validated += mskAltura_Validated;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(54, 50);
            label1.Name = "label1";
            label1.Size = new Size(63, 15);
            label1.TabIndex = 2;
            label1.Text = "Peso Atual";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(54, 103);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 3;
            label2.Text = "Altura";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(54, 168);
            label3.Name = "label3";
            label3.Size = new Size(27, 15);
            label3.TabIndex = 4;
            label3.Text = "imc";
            label3.Click += label3_Click;
            // 
            // txtimc
            // 
            txtimc.Location = new Point(226, 165);
            txtimc.Name = "txtimc";
            txtimc.Size = new Size(308, 23);
            txtimc.TabIndex = 5;
            txtimc.TextChanged += txtimc_TextChanged;
            // 
            // button1
            // 
            button1.Location = new Point(54, 291);
            button1.Name = "button1";
            button1.Size = new Size(138, 114);
            button1.TabIndex = 6;
            button1.Text = "calcular";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(248, 291);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(140, 114);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "limpar ";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(460, 291);
            button3.Name = "button3";
            button3.Size = new Size(140, 114);
            button3.TabIndex = 8;
            button3.Text = "sair";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(btnLimpar);
            Controls.Add(button1);
            Controls.Add(txtimc);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(mskAltura);
            Controls.Add(mskPeso);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaskedTextBox mskPeso;
        private MaskedTextBox mskAltura;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtimc;
        private Button button1;
        private Button btnLimpar;
        private Button button3;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
    }
}
