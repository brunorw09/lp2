﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais 
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox1.Text, out numero1))
            { 
                
        }
            else
            errorProvider1.SetError(textBox1, "");
            textBox1.Focus(); 
            }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {



            try
            {
                errorProvider2.SetError(textBox2, "");
                numero2 = Convert.ToDouble(textBox2.Text);
            }
            catch
            {
                errorProvider2.SetError(textBox2, "numero 2 inválido");
                textBox2.Focus();
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox3.Text = (numero1 + numero2).ToString();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox3.Text = (numero1 - numero2).ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não é Possível dividir por 0!");
            }
            else
                textBox3.Text = (numero1 / numero2).ToString("N10");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();



        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                "Saida", MessageBoxButtons.YesNo,
                         MessageBoxIcon.Question) ==
                         DialogResult.Yes)

            {
                Close();
            }            
                        
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox3.Text = (numero1 * numero2).ToString();
        }
    }
}
